//
//  ViewController.swift
//  halleBerry
//
//  Created by John Zalubski on 9/19/19.
//  Copyright © 2019 John Zalubski. All rights reserved.
//
//CollectionViewCell not displaying cells or loading core data string

//I am trying to save a core data string via the first class than load that string into a collectionviewcell textlabal. I am doing all of this without the use of any storyboards. I am not getting any compile errors. It is just when I load this class nothing is appearing.



import UIKit;import CoreData  

class Cell: UICollectionViewCell {
    
    static var identifier: String = "Cell"
    
    weak var textLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let textLabel = UILabel(frame: .zero)
        textLabel.translatesAutoresizingMaskIntoConstraints = false
        self.contentView.addSubview(textLabel)
        NSLayoutConstraint.activate([
            self.contentView.centerXAnchor.constraint(equalTo: textLabel.centerXAnchor),
            self.contentView.centerYAnchor.constraint(equalTo: textLabel.centerYAnchor),
            ])
        self.textLabel = textLabel
        self.reset()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.reset()
    }
    
    func reset() {
        self.textLabel.textAlignment = .center
    }
}
class ViewController: UIViewController {
      var itemsName: [Item] = []
    weak var collectionView: UICollectionView!
    
    
    override func loadView() {
        super.loadView()
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: UICollectionViewFlowLayout())
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(collectionView)
        NSLayoutConstraint.activate([
            self.view.topAnchor.constraint(equalTo: collectionView.topAnchor),
            self.view.bottomAnchor.constraint(equalTo: collectionView.bottomAnchor),
            self.view.leadingAnchor.constraint(equalTo: collectionView.leadingAnchor),
            self.view.trailingAnchor.constraint(equalTo: collectionView.trailingAnchor),
            ])
        self.collectionView = collectionView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        self.collectionView.register(Cell.self, forCellWithReuseIdentifier: Cell.identifier)
        self.collectionView.alwaysBounceVertical = true
        self.collectionView.backgroundColor = .brown
        
        collectionView.reloadData()
        

    }
}

extension ViewController: UICollectionViewDataSource {
      
    func collectionView(_ collectionView: UICollectionView,
                        numberOfItemsInSection section: Int) -> Int {
        return self.itemsName.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: Cell.identifier, for: indexPath) as! Cell

        
    


     
    

            let user = itemsName[indexPath.row]
            cell.textLabel?.text = ("\nCourse: \(user.atBATS!) Score: ")
        cell.backgroundColor = UIColor.blue
        cell.textLabel.textColor = UIColor.black
            return cell
    
    }
}

extension ViewController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
    }
}

extension ViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.bounds.width, height: 44)
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0) //.zero
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 40
    }
}
       













class draw: UIViewController {
    
    var nextPage = UIButton()
    var clear = UIButton()
    var submitToDB = UIButton()
    
    
    
    
    var itemName : [NSManagedObject] = []
    
    var myLayer = CALayer()
    var path = UIBezierPath()
    var startPoint = CGPoint()
    var touchPoint = CGPoint()
    
    
    
    var playName = UITextField()
    
    
    
    
    
    var drawPlace = UIImageView()//The imageview
    
    
    
    
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        if let point = touch?.location(in: drawPlace){
            startPoint = point
            
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        if let point = touch?.location(in: drawPlace){
            touchPoint = point
        }
        
        path.move(to: startPoint)
        path.addLine(to: touchPoint)
        startPoint = touchPoint
        draw()
    }
    func draw() {
        submitToDB.layer.cornerRadius = 0
        drawPlace.clipsToBounds = true
        drawPlace.isMultipleTouchEnabled = false
        let strokeLayer = CAShapeLayer()
        strokeLayer.fillColor = nil
        strokeLayer.lineWidth = 2
        strokeLayer.strokeColor = UIColor.blue.cgColor
        strokeLayer.path = path.cgPath
        drawPlace.layer.insertSublayer(strokeLayer, below: myLayer)
        drawPlace.setNeedsDisplay()
        
        
        let star:UIImage = UIImage(named: "SHAM.png")!
        let newSize = CGSize(width: star.size.width, height: star.size.height  )
        
        UIGraphicsBeginImageContextWithOptions(newSize, false, star.scale)
        
        
        
        star.draw(in: CGRect(x: newSize.width/12,
                             y: newSize.height/8,
                             width: newSize.width/1.2,
                             height: newSize.height/1.2),
                  blendMode:CGBlendMode.normal, alpha:1)
        
        
        
        let newImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        
        drawPlace.image = newImage
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.brown
        
        clear.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(clear)
        submitToDB.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(submitToDB)
        
        
        nextPage.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nextPage)
        
        drawPlace.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(drawPlace)
        
        playName.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(playName)
        
        
        
        
        
        draw()
        
        
        
        clear.backgroundColor = UIColor.blue
        clear.setTitle("clear", for: .normal)
        submitToDB.setTitle("Submit", for: .normal)
        nextPage.setTitle("next", for: .normal)
        submitToDB.backgroundColor = UIColor.purple
        drawPlace.backgroundColor = UIColor.orange
        playName.backgroundColor = UIColor.orange
        playName.placeholder = "enter play name"
        playName.textAlignment = .center
        nextPage.backgroundColor = UIColor.gray
        NSLayoutConstraint.activate ([
            submitToDB.trailingAnchor.constraint(equalTo: view.centerXAnchor, constant :37.5),
            submitToDB.topAnchor.constraint(equalTo: view.centerYAnchor, constant : 225),
            submitToDB.widthAnchor.constraint(equalToConstant: 75),
            submitToDB.heightAnchor.constraint(equalToConstant: 50),
            
            nextPage.trailingAnchor.constraint(equalTo: view.centerXAnchor, constant :37.5),
            nextPage.topAnchor.constraint(equalTo: view.centerYAnchor, constant : 280),
            nextPage.widthAnchor.constraint(equalToConstant: 75),
            nextPage.heightAnchor.constraint(equalToConstant: 50),
            
            
            clear.trailingAnchor.constraint(equalTo: view.centerXAnchor, constant :37.5),
            clear.topAnchor.constraint(equalTo: view.centerYAnchor, constant : -200),
            clear.widthAnchor.constraint(equalToConstant: 75),
            clear.heightAnchor.constraint(equalToConstant: 50),
            
            
            playName.trailingAnchor.constraint(equalTo: view.centerXAnchor, constant :75),
            playName.topAnchor.constraint(equalTo: view.centerYAnchor, constant : -275),
            playName.widthAnchor.constraint(equalToConstant: 150),
            playName.heightAnchor.constraint(equalToConstant: 50),
            
            drawPlace.trailingAnchor.constraint(equalTo: view.centerXAnchor, constant :150),
            drawPlace.topAnchor.constraint(equalTo: view.centerYAnchor, constant : -100),
            drawPlace.widthAnchor.constraint(equalToConstant: 300),
            drawPlace.heightAnchor.constraint(equalToConstant: 300),
            
            ])
        //        nextPage.isHidden = true
        clear.addTarget(self, action: #selector(clearAction), for: .touchUpInside)
        submitToDB.addTarget(self, action: #selector(submitAction), for: .touchUpInside)
        nextPage.addTarget(self, action: #selector(moveRight), for: .touchUpInside)
        
    }
    @objc func moveRight() {
        
       let jake = ViewController()
        self.present(jake, animated: true, completion: nil)
    
    }
    func saver(text: String) {
        let vex = drawPlace.screenshot().pngData()
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Item", in: managedContext)!
        let item = NSManagedObject(entity: entity, insertInto: managedContext)
        let fetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Item")
        
        
        if let data = vex{
            item.setValue(data, forKey: "image")
            print(data)
        }
        
        
        item.setValue(text, forKey: "atBATS")
        
        do {
            let result = try? managedContext.fetch(fetch) as? [Item]
            print("Queen",result?.count)
            try? managedContext.save()
            
            print("Text = \(text)")
            
        }
        catch {
            print("Could not save")
        }
        
    }
    
    
    
    @objc func clearAction() {
        
        path.removeAllPoints()
        drawPlace.layer.sublayers = nil
        drawPlace.setNeedsDisplay()
        
        
        
        draw()
        drawPlace.layer.addSublayer(myLayer)
        let myImage = UIImage(named: "bb.png")?.cgImage
        
        myLayer.contents = myImage
        
        
    }
    @objc func submitAction() {
        
        
        if let textEntered = self.playName.text {
            if textEntered.isEmpty != true {
                saver(text: textEntered)
                print("Saves the textfield text")
            } else { print("Text Field was empty nothing to save.")}
        } else {  print("The text field was nil")
        }
        
        playName.resignFirstResponder()
        
        clearAction()
        
        
        
    }
    
    
    
    
}

extension UIView {
    func screenshot() -> UIImage {
        return UIGraphicsImageRenderer(size: bounds.size).image { _ in
            drawHierarchy(in: CGRect(origin: .zero, size: bounds.size), afterScreenUpdates: true)
        }
    }
}
class listOfPlays : UIViewController {
    
}
